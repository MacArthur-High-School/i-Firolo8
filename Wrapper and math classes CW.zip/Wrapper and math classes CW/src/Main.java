import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int x = (int) (3 * Math.random() + 5);
        System.out.println(x);
        }
    }